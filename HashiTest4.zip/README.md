Hello!

You need to run:

meteor npm install 

before you can launch the app.
